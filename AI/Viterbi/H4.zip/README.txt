Readme for ViterbiAlgNew.py

It works just reaaaaallly slow if you try to run it, it may take over two hours or 30 minutes.
The code given just runs really slow and I hadn't improved it much.